# Dummy functions, classes to make python compiler blind


def Date(*_):
    pass


class Document:
    pass


class window:
    pass


class Math:
    pass


class JSON:
    pass


class console:
    pass


class screen:
    pass


def alert(msg):
    pass
