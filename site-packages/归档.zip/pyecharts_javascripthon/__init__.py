# flake8: noqa
from pyecharts_javascripthon._version import __version__
from pyecharts_javascripthon._version import __author__
