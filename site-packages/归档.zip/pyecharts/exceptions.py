# coding=utf-8


class InvalidConfiguration(Exception):
    pass


class RegionNotFound(Exception):
    pass
