# coding=utf-8
from typing import (
    Any,
    Callable,
    Iterable,
    List,
    Mapping,
    Optional,
    Sequence,
    Tuple,
    Union,
)

Numeric = Union[int, float]
JSFunc = str
